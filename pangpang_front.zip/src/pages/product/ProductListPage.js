import ProductListComponent from '../../components/product/ProductListComponent';

const ProductListPage = () => {

  return (

    <ProductListComponent />
      
  )
}

export default ProductListPage;