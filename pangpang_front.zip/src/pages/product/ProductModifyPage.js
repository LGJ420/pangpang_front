import ProductModifyComponent from "../../components/product/ProductModifyComponent"


const ProductModifyPage = () => {

  return (
    <ProductModifyComponent />
  )
}

export default ProductModifyPage;