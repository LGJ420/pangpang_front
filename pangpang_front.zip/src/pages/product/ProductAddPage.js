import ProductAddComponent from '../../components/product/ProductAddComponent';

const ProductAddPage = () => {

  return (

    <ProductAddComponent />
      
  )
}

export default ProductAddPage;