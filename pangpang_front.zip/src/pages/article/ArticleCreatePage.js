import ArticleCreateComponent from "../../components/article/ArticleCreateComponent";

const ArticleCreatePage = () => {
  
  return (

    <ArticleCreateComponent />

  );

};

export default ArticleCreatePage;