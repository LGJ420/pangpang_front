import ArticleListComponent from "../../components/article/ArticleListComponent";

const ArticleListPage = () => {

    return (

        <ArticleListComponent />

    );
        
};

export default ArticleListPage;