import ArticleModifyComponent from "../../components/article/ArticleModifyComponent";

const ArticleModifyPage = () => {

  return (

    <ArticleModifyComponent />

  );

};

export default ArticleModifyPage;