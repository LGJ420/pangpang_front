import ArticleReadComponent from "../../components/article/ArticleReadComponent";

const ArticleReadPage = () => {
  
    return (

      <ArticleReadComponent />

    );

};

export default ArticleReadPage;