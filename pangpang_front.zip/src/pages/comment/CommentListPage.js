import CommentListComponent from "../../components/comment/CommentListComponent";

const CommentListPage = () => {

  return (

    <CommentListComponent />

  );

};

export default CommentListPage;