import CommentModifyComponent from "../../components/comment/CommentModifyComponent";

const CommentModifyPage = () => {

  return (
    
    <CommentModifyComponent />

  );
};

export default CommentModifyPage;