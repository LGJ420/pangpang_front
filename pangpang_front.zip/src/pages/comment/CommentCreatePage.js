// import CommentCreateComponent from "../../components/comment/CommentCreateComponent";

// const CommentCreatePage = () => {

//     return (

//         <CommentCreateComponent />

//     );

// }

// export default CommentCreatePage;