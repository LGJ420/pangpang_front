import { Outlet } from "react-router-dom";

const OrdersIndexPage = () => {

    return (
        
        <Outlet />
        
    );
}

export default OrdersIndexPage;