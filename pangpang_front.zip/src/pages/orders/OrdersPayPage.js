import OrdersPayComponent from "../../components/orders/OrdersPayComponent";

const OrdersPayPage = () => {

    return (
        
        <OrdersPayComponent />
        
    );
}

export default OrdersPayPage;