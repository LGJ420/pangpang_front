import MemberSignupComponent from '../../components/member/MemberSignupComponent';

const MemberSignupPage = () => {
 
    return (

        <MemberSignupComponent />

    );
}

export default MemberSignupPage;