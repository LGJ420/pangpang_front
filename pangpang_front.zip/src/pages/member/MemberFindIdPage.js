import MemberFindIdComponent from "../../components/member/MemberFindIdComponent";

const MemberFindIdPage = () => {

    return (

        <MemberFindIdComponent />

    );
}

export default MemberFindIdPage;