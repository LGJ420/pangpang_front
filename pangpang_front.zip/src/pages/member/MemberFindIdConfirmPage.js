import MemberFindIdConfirmComponent from './../../components/member/MemberFindIdConfirmComponent';

const MemberFindIdConfirmPage = () => {

    return (

        <MemberFindIdConfirmComponent />

    );
}

export default MemberFindIdConfirmPage;