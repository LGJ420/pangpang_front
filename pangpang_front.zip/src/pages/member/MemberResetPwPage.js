import MemberResetPwComponent from '../../components/member/MemberResetPwComponent';

const MemberResetPwPage = () => {

    return (
        
        <MemberResetPwComponent />

    );
};

export default MemberResetPwPage;