import MemberLoginComponent from '../../components/member/MemberLoginComponent';

const MemberLoginPage = () => {

    return (
            
        <MemberLoginComponent />

    );
}

export default MemberLoginPage;