import MemberResetPwConfirmComponent from '../../components/member/MemberResetPwConfirmComponent';

const MemberResetPwConfirm = () => {

    return (
        
        <MemberResetPwConfirmComponent />

    );
};

export default MemberResetPwConfirm;