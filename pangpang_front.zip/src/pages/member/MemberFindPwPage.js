import MemberFindPwComponent from '../../components/member/MemberFindPwComponent';

const MemberFindPwPage = () => {

    return (
            
        <MemberFindPwComponent />

    );
}

export default MemberFindPwPage;