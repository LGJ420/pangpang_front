import MemberSignupConfirmComponent from '../../components/member/MemberSignupConfirmComponent';

const MemberSignupConfirmPage = () => {

    return (

        <MemberSignupConfirmComponent />
        
    );
};

export default MemberSignupConfirmPage;