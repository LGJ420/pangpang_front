import CratListComponent from "../../components/cart/CartListComponent"

const CratListPage = () => {

    return (
        
        <CratListComponent />
    );
}

export default CratListPage;