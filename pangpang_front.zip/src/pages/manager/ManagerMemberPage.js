import ManagerMemberComponent from "../../components/manager/ManagerMemberComponent";

const ManagerMemberPage = () => {

    return (

        <ManagerMemberComponent />
    );
}

export default ManagerMemberPage;