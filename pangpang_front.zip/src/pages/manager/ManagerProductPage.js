import ManagerProductComponent from "../../components/manager/ManagerProductComponent";

const ManagerProductPage = () => {

    return (

        <ManagerProductComponent />
    );
}

export default ManagerProductPage;