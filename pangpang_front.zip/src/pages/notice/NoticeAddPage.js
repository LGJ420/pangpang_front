import NoticeAddComponent from "../../components/notice/NoticeAddComponent";

const NoticeAddPage = () => {

    return (

        <NoticeAddComponent />

    );

}

export default NoticeAddPage;