import NoticeListComponent from "../../components/notice/NoticeListComponent";

const NoticeListPage = () => {

    return (

        <NoticeListComponent />

    );

}

export default NoticeListPage;