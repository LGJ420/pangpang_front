import CashWalletComponent from "../../components/cash/CashWalletComponent";

const CashWalletPage = () => {

    return (
        
        <CashWalletComponent />
    );
}

export default CashWalletPage;