import MypageCommentComponent from "../../components/mypage/MypageCommentComponent";

const MypageCommentPage = () => {

    return (
        
        <MypageCommentComponent />
        
    );
}

export default MypageCommentPage;