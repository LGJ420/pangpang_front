import MypageArticleListComponent from "../../components/mypage/MypageArticleListComponent";

const MypageArticleListPage = () => {

    return (
        
        <MypageArticleListComponent />

    );
}

export default MypageArticleListPage;