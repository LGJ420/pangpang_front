import MypageProfileBeforeComponent from './../../components/mypage/MypageProfileBeforeComponent';

const MypageProfileBeforePage = () => {

    return (

        <MypageProfileBeforeComponent/>
        
    );
}

export default MypageProfileBeforePage;