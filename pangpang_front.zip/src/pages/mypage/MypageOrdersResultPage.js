import OrdersResultComponent from "../../components/orders/OrdersResultComponent"

const MypageOrdersResultPage = () => {

    return (

        <OrdersResultComponent />
        
    );
}

export default MypageOrdersResultPage;