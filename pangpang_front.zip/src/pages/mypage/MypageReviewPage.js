import MypageReviewComponent from "../../components/mypage/MypageReviewComponent"

const MypageReviewPage = () => {

    return (

        <MypageReviewComponent/>
        
    );
}

export default MypageReviewPage;