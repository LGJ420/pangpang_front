import MypageProfileComponent from "../../components/mypage/MypageProfileComponent"

const MypageProfilePage = () => {

    return (

        <MypageProfileComponent/>
        
    );
}

export default MypageProfilePage;